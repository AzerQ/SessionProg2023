#include <vector>

namespace Lab5_2{
    void Task1(); //Первая задача
    void Task2(); //Вторая задача
    std::vector<std::vector<double>> InputMatrix(int n, int m);
    std::vector<std::vector<double>> matrixMult(std::vector<std::vector<double>>& a, std::vector<std::vector<double>>& b);
}