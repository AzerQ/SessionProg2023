#ifndef LAB3_H
#define LAB3_H

#include <iostream>

namespace Lab3
{
    void Task1();
    void Task2();
    void Task3();
}

#endif // LAB3_H