#ifndef LAB2_H
#define LAB2_H

#include <iostream>

namespace Lab2
{
    void Task1();
    void Task2();
    void Task3();
}

#endif // LAB2_H