#ifndef LAB1_H
#define LAB1_H

#include <iostream>
#include <math.h>

namespace Lab1
{
    void Task1();
    void Task2();
    double f(double x);
    void Task3();
}

#endif // LAB1_H