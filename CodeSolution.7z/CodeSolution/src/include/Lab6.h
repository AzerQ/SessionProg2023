#ifndef LAB6_H
#define LAB6_H

#include <string>

namespace Lab6 {
    void Task1();
    void Task2();
    void Task3();
}

#endif
